# Forge — prompt to working app

Full-stack AI app generator. FastAPI + SQLite backend, single-file HTML frontend.
Every generation produces a **complete multi-file project**, not one HTML page:

```
server.py            FastAPI + SQLite backend with a real REST API
requirements.txt
static/index.html    Tailwind (CDN) markup
static/styles.css    custom styles on top of Tailwind
static/app.js        fetch() calls against the backend
README.md            how to run it
```

The build view shows a tab per file and streams each one as it is written. The live preview
inlines the CSS and JS into the HTML and answers `/api/*` calls with an in-memory stand-in,
so the app is clickable in the browser before you ever start the backend. Download the
`.zip`, `pip install -r requirements.txt`, `uvicorn server:app --reload`, and the real
backend takes over.

## Generation engines

Forge tries four engines in order, and the header badge always shows which one is live:

1. **Perplexity built-in model** (default here) — `claude_sonnet_4_6` with extended
   thinking. Phase one writes an architecture plan: schema, endpoints, screens, state.
   Phase two writes every file against that plan. No API key needed inside Perplexity
   Computer; set `PPLX_MODEL`, `PPLX_THINK_BUDGET` or `PPLX_BUILD_TOKENS` to tune it.
2. **OpenRouter reasoning model** — same two-phase flow via `OPENROUTER_API_KEY`.
   Used when the built-in models are not reachable, e.g. on your own machine.
3. **Local Ollama** — the same two phases against `OLLAMA_MODEL` (default
   `qwen2.5-coder:3b`).
4. **Built-in generator** — a deterministic full-stack project so the flow never dead-ends.

```bash
export OPENROUTER_API_KEY=sk-or-v1-...     # your key
export OPENROUTER_MODEL=openrouter/free    # or any model slug you prefer
export OLLAMA_MODEL=qwen2.5-coder:3b
```

Because `openrouter/free` routes to a different free model on every call, some calls come
back malformed — the server retries with progressively simpler request shapes, and falls
back to the next engine only if every attempt fails.

## Integrations, wired automatically

Forge reads the brief and the answers, works out which services the app needs, and generates
each one as its own module under `integrations/`. Nothing is a stub: every integration ships
two paths.

| Integration | Keys | With no keys at all |
| --- | --- | --- |
| Google sign-in | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | local sign-in form, same session cookie, same `users` table |
| Supabase Postgres | `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` | the same storage functions run on local SQLite |
| File uploads | `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_ENDPOINT` | files land in `./uploads`, served from `/uploads` |
| Stripe payments | `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | a local mock checkout that marks the order paid |
| Transactional email | `RESEND_API_KEY`, `MAIL_FROM` | messages go to an `outbox` table and the console |
| Maps and places | `MAPS_API_KEY` | Leaflet with OpenStreetMap tiles, which need no key |
| AI text | `OPENAI_API_KEY`, `OPENAI_BASE_URL`, `AI_MODEL` | a clearly-labelled canned response |
| Realtime updates | none | a WebSocket on the app's own server |

The build view shows a chip per detected integration — green when the keys are already in
place, amber when it is running in dev mode. Click one to see its module path, its
environment variables, and the exact steps to switch it live.

### The key vault

Admin → Integrations holds one field per key. Paste a key once and every app generated from
then on gets it written into its own `.env`, so the integration is live the first time the
project runs. Values are stored server-side and are never sent back to a browser — the API
only ever reports whether a key is set.

### What makes it work on first run

Every project with an integration gets `integrations/env.py`, a dependency-free loader that
reads `.env` into `os.environ` at import time, and `server.py` imports it on its first line.
So `uvicorn server:app` is genuinely all it takes — no export step, no `python-dotenv`. The
loader also maps the common alternate spellings (`S3_ACCESS_KEY` → `AWS_ACCESS_KEY_ID`, and
so on), so a key lands wherever the code looks for it.

Generated integrations also survive a *wrong* key: the call to the provider is wrapped, the
error is logged, and the dev path takes over, so a typo in `.env` degrades the feature
instead of returning a 500. `GET /api/health` on any generated app reports which
integrations are live and which are in dev mode, without exposing values.

## Publishing

`Publish live` on a finished app registers it at `/p/<slug>`, served publicly with no
auth. Published pages get indexable meta tags plus a canonical link, are listed in
`/sitemap.xml`, and `robots.txt` allows crawlers on `/p/` while blocking `/api/`.
Set `PUBLIC_BASE_URL=https://yourdomain.com` so those links and the sitemap use your real
domain — that is what makes them Google-indexable rather than localhost-only.

```bash
export PUBLIC_BASE_URL=https://forge.yourdomain.com
```

Re-publishing the same project updates the existing address instead of creating a new one.

## Run it on your PC (real AI output)

```bash
ollama serve                 # keep running
ollama pull qwen2.5-coder:3b # already done

pip install fastapi uvicorn httpx
python api_server.py         # http://localhost:8000
```

Then open `index.html` in a browser (double-click is fine — it talks to
`http://localhost:8000`).

Optional env vars:

| Var | Default | Meaning |
|---|---|---|
| `OLLAMA_URL` | `http://localhost:11434` | Ollama endpoint |
| `OLLAMA_MODEL` | `qwen2.5-coder:3b` | Model tag to use |
| `ADMIN_PASS` | `5463yr7y3` | Admin panel password |
| `OPENROUTER_API_KEY` | – | Enables the reasoning engine |
| `OPENROUTER_MODEL` | `openrouter/free` | OpenRouter model slug |
| `PUBLIC_BASE_URL` | request host | Domain used in published links and the sitemap |

If Ollama is not reachable the server falls back to a built-in deterministic
generator so the whole flow still works — the header pill tells you which engine
is live.

## How it works

- `POST /api/signup` — mints an `FRG-…` access code, grants 10 credits, and binds
  the browser so the user stays signed in without re-entering the code.
- `POST /api/login` — sign in from another device with the code.
- `POST /api/clarify` (1 credit) — the model proposes 4 targeted questions about
  the app idea; falls back to generic product questions.
- `GET /api/models` — the model catalog with each model's per-file credit rate.
- `POST /api/generate` (billed per file) — four phases over SSE: the model reasons about
  the architecture and art direction (`think` / `plan` events stream into the UI panel),
  writes every file (`chunk` events type it out live), then every file is statically
  checked and the preview is rendered. Stores the project when done. Accepts `model`
  and `resume_project`.
- `POST /api/fix` — sends the checker's findings back to the model, which rewrites only
  the broken files. Billed per rewritten file.
- `GET /api/check/{id}` — re-run the static checks on a stored project.
- `POST /api/publish` — publishes the app at `/p/<slug>`; `GET /api/published` lists yours,
  `DELETE /api/publish/<slug>` takes it down.
- `GET /p/<slug>`, `/robots.txt`, `/sitemap.xml` — the public, crawlable surface.
- `GET /api/download/{id}` — zip of the project.
- `POST /api/redeem` — single-use gift codes; batch labels stop one user
  redeeming several codes from the same batch.
- `POST /api/admin/*` — password-gated stats, gift-card minting, credit adjustments.

Data lives in `forge.db` (SQLite) next to the server.

## Credits

Signup 10 · questions 1 · **the build is billed per file at the chosen model's rate** ·
gift cards top up. Files Forge writes itself (the integration loader, `.env`, package
stubs) are free — you only pay for code the model produced.

| Model | Per file |
|---|---|
| Claude Haiku 4.5 | 1 |
| Claude Sonnet 4.6 (default) | 2 |
| Gemini 3.1 Pro | 3 |
| GPT-5.1 | 3 |
| Claude Opus 4.7 | 5 |

The picker sits on the questions page and the choice is remembered between visits.
A running meter under the build steps shows files billed, credits spent and credits left.

### Running out mid-build

Billing happens the moment a file finishes, so a build can stop halfway. When it does,
every file written so far is **saved**, the stream ends with an `exhausted` event and the
UI shows a panel naming those files with a redeem box. Redeem a gift code and
"Finish the build" resumes the same project: the model is given the finished files and
told to emit only what is still missing, so nothing is paid for twice.

## Checking and repair

After the files are written, `verify.py` statically checks the whole project without
running it: Python syntax, JavaScript bracket balance, truncated or stubbed files,
every `fetch('/api/...')` against the routes that actually exist in `server.py`, every
`getElementById` / `querySelector` against the ids in the markup, and every `src`/`href`
against the generated files. Anything it finds appears as a side popup with a **Fix it**
button, which streams the findings back to the model; only the broken files are
rewritten, and they are re-checked afterwards.

## Publishing

`Publish live` always produces a page at `/p/<slug>` served by Forge, with `robots.txt`
and `sitemap.xml` so it can be indexed. Save a `VERCEL_TOKEN` in the admin panel's
Integrations tab and Publish additionally uploads the app to Vercel and returns a real
public URL on its own domain. A failed deploy never blocks publishing — the
Forge-hosted copy stays up and the error is reported.

## The public gallery

Publishing an app does two things: it serves the app at its own address, and it lists it in
**Explore** where everyone can see it.

- `GET /api/explore?sort=new|top|remixed|discussed&q=` — the feed. Open to signed-out
  visitors; signing in only adds your own vote state. Backend-only projects (no frontend to
  render) are filtered out so the grid never shows an empty tile.
- `GET /api/pub/{slug}` — one app, re-flattened from its current source files so the inline
  preview always carries the latest shims.
- `POST /api/vote {slug, val}` — `val` is `1` or `-1`. Sending the same value again clears
  your vote; sending the opposite switches it. One vote per person per app.
- `GET /api/comments/{slug}`, `POST /api/comments {slug, body}`, `DELETE /api/comments/{id}`
  — you can only delete your own.
- `POST /api/remix {slug}` — copies the published project's files into a new project you own,
  bumps the original's remix count, and records what it came from. **Copying is free.**
  Credits are only spent when you then ask the model to change something.

Every account gets a public handle (`builder-caez`) derived from its auth code, so authors and
commenters have a name in the gallery without anyone having to pick a username.

### Changing an app after it is built

The build screen has a permanent **Change this app** box. Describe the change in plain words
and the model re-reads the project, rewrites only the files it needs to, and updates the
preview. It is billed exactly like a repair: the model's per-file rate for each file it
actually rewrites. There is also a **Re-check the code** button that re-runs the static
checker on demand.

### Shareable links

Published URLs are derived from the address you actually reached Forge on
(`PUBLIC_BASE_URL`, then `X-Forwarded-Host`/`X-Forwarded-Proto`, then `Origin`, then
`Referer`), and localhost is rejected at every step. Running Forge only on your own machine
means the link works for you but not for anyone else — save a `VERCEL_TOKEN` in the admin
panel and every publish also uploads to real hosting on its own domain.

### Previews never crash on storage

Gallery thumbnails and detail previews run in a sandbox without same-origin access, where
touching `localStorage` throws. The preview shim now installs a working in-memory
`localStorage` and `sessionStorage` when the real ones are unreachable, so a generated app
that saves state still runs in every preview surface.

### Where the database lives

`forge.db` holds every account's sign-in code, so it is kept **outside** the project folder —
by default `../.forge-data/forge.db`, overridable with `FORGE_DB`. An existing database in the
old in-project location is moved there automatically on first run. Nothing that gets served or
bundled contains account data.
